//
//  addDishDelegate.swift
//  CuisineNation
//
//  Created by Fahad Shaikh on 2017-04-10.
//  Copyright © 2017 Fahad Shaikh. All rights reserved.
//

import Foundation
protocol AddDishDelegate {
    
    /* Function to be developed
     here you can see only the definition */
    
    func addMealsTable(_ meal:Guard)
    
}
